// Exercise 1.3 Spot the errors. The correct version should closely resemble the answer to exercise 1.1.

#include <iostream>
using namespace std;

int main() {
  cout << endl
       << "Hello World"
       << endl                     // A semicolon is missing from the end of this line

  return0;                         // A space is required between 'return' and '0'
)      