// Exercise 1.1 Writing the line "Hello World" to the screen.

#include <iostream>
using std::cout;
using std::endl;

int main() {
  cout << endl
       << "Hello World"
       << endl;

  return 0;
}