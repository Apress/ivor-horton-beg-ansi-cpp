// Exercise 10.4 This file is the same as for Exercise 10.3. 

// print.h
#ifndef PRINT_H
#define PRINT_H

#include <string>
using std::string;

namespace print1 {
  // Function prototype
  void print(const string& s);
}

namespace print2 {
  // Function prototype
  void print(const string& s);
}

#endif