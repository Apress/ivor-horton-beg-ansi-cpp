// Exercise 10.4 This file is the same as for Exercise 10.3. 

// printthis.cpp
#include "printthis.h"
#include "print.h"

void print_this(const string& s) {
  print1::print(s);
}