// Exercise 10.4 This file is the same as for Exercise 10.3. 

// printthat.cpp
#include "printthat.h"
#include "print.h"

void print_that(const string& s) {
  print2::print(s);
}