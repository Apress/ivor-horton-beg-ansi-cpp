// Program 11.2 Using pointers to Box objects.  File:  box.cpp
// Defines the Box member function
#include "box.h"

// Box function to calculate volume
double Box::volume() {
  return length * width * height;
}
