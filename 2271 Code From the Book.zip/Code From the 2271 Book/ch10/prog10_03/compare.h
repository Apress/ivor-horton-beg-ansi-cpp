// compare.h
namespace compare {
  double max(const double* data, int size);
  double min(const double* data, int size);
}
