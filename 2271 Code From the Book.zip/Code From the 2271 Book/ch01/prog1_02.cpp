// Program 1.2 Using escape sequences
#include <iostream>
using std::cout;

int main() {
  cout << "\n\"Least said\n\t\tsoonest mended.\"\n\a";
  return 0;
}
