// Program 1.1 A simple C++ program
#include <iostream>
int main() {
  std::cout << "The best place to start is at the beginning";
  return 0;
}
