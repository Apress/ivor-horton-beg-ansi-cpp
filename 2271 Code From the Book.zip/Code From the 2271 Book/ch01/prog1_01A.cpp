// Program 1.1A A simple C++ program
#include <iostream>
using std::cout;
int main() {
  cout << "The best place to start is at the beginning";
  return 0;
}
