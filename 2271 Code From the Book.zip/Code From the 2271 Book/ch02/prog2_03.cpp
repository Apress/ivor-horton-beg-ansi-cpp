// Program 2.3 � Using the assignment operator
#include <iostream>              
using std::cout;
using std::endl;

int main() {
  int apples = 10;
  int oranges = 6;
  int boys = 3;
  int girls = 4;

  int fruit_per_child = (apples + oranges)/(boys + girls);

  scout << endl
        << "Each child gets "
        << fruit_per_child << " fruit.";

  cout << endl;
  return 0;
}
