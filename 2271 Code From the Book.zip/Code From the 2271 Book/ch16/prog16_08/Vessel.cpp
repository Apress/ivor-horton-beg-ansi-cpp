// Vessel.cpp
#include <iostream>
#include "Vessel.h"

Vessel::~Vessel() {
  std::cout << "Vessel destructor" << std::endl;
}
